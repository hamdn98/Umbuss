# Creative Nexus — Compact Creative Studio (Beta 0.1)

A lightweight, static creative workspace prototype designed for GitHub Pages and modern mobile/desktop browsers.

## Included in this first build
- Responsive dark graphite workspace.
- SVG-based artboard with rectangle, ellipse, freehand path, text, selection and move tools.
- Layer list, properties inspector, duplicate/delete, undo/redo.
- Native `.nexus` project save/open (JSON document format).
- SVG import (basic top-level shapes/text/paths) and SVG/PNG export.
- Motion timeline with keyframes for position, size, rotation and opacity.
- WebM animation recording through browser `MediaRecorder`.

## Important limitations in Beta 0.1
- This is a working first slice, not yet the complete professional suite.
- Boolean pathfinder (Union/Subtract/Intersect/Exclude/Divide), advanced Bezier node editing, masks, multi-track audio/video editing, and full typography controls are not implemented yet.
- Video export currently produces WebM. MP4/MOV need a real FFmpeg transcoding stage; the app deliberately does not rename WebM files to MP4/MOV.
- SVG import currently supports basic top-level rect/circle/ellipse/text/path elements. Complex SVG groups, transforms, gradients and filters need a later importer pass.
- Projects are stored locally when downloaded; there is no cloud sync.

## Run locally
Open `index.html` in a modern browser. For best file import/export behavior, serve the folder over HTTP:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Deploy to GitHub Pages
1. Create a GitHub repository and upload the contents of this folder to the repository root.
2. Open **Settings → Pages**.
3. Select **Deploy from a branch**, choose `main` and `/ (root)`.
4. Save and wait for the Pages URL.

No build step or npm install is required for this beta.
