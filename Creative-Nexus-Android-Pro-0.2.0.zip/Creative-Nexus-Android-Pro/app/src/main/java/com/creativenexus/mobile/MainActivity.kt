package com.creativenexus.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.creativenexus.engine.vector.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0E14)
private val SurfaceDark = Color(0xFF171C26)
private val Purple = Color(0xFF8B7CFF)
private val TextMuted = Color(0xFF8D96A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
private fun NexusApp() {
    var doc by remember { mutableStateOf(VectorDocument()) }
    var tool by remember { mutableStateOf("Select") }
    val history = remember { DocumentHistory(50) }
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Ready · Vector workspace") }

    fun commit(next: VectorDocument) {
        history.commit(doc, next)
        doc = next
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = SurfaceDark)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("CREATIVE NEXUS", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("ANDROID CREATIVE WORKSPACE", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                Text("0.2 PRO", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Tool("Select", tool == "Select") { tool = "Select" }
                Tool("Rectangle", tool == "Rectangle") { tool = "Rectangle"; commit(doc.add(VectorObject(kind=ShapeKind.RECTANGLE, bounds=RectF(360f,360f,680f,590f)))) }
                Tool("Ellipse", tool == "Ellipse") { tool = "Ellipse"; commit(doc.add(VectorObject(kind=ShapeKind.ELLIPSE, bounds=RectF(390f,390f,690f,690f)))) }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) {
                VectorCanvas(doc, onChange = { next -> doc = next }, onCommit = { next -> commit(next) }, modifier = Modifier.fillMaxSize())
                Surface(color = Color(0xDD171C26), shape = RoundedCornerShape(9.dp), modifier = Modifier.align(Alignment.TopStart).padding(9.dp)) {
                    Text("${doc.objects.size} OBJECTS  ·  ${tool.uppercase()}", Modifier.padding(horizontal=10.dp, vertical=7.dp), color=TextMuted, fontSize=9.sp)
                }
            }
            Surface(color = SurfaceDark, shape = RoundedCornerShape(topStart=20.dp, topEnd=20.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("DOCUMENT", color=TextMuted, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                            Text("${doc.width} × ${doc.height} px  ·  ${doc.objects.size} objects", color=Color.White, fontSize=13.sp)
                        }
                        Text(status, color=TextMuted, fontSize=9.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        SmallAction("Undo", Modifier.weight(1f)) { history.undo(doc)?.let { doc = it } }
                        SmallAction("Redo", Modifier.weight(1f)) { history.redo(doc)?.let { doc = it } }
                        SmallAction("Delete", Modifier.weight(1f)) { commit(doc.removeSelected()) }
                        SmallAction("Save", Modifier.weight(1f)) {
                            ProjectStore.save(NexusContext.current, doc)
                            status = "Project saved"
                        }
                        SmallAction("PNG", Modifier.weight(1f)) {
                            scope.launch {
                                val file = withContext(Dispatchers.IO) { PngExporter.export(NexusContext.current, doc) }
                                status = "PNG exported: ${file.name}"
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Drag shapes to move · Undo history · Local project save · PNG export", color=TextMuted, fontSize=9.sp)
                }
            }
        }
    }
}

private object NexusContext {
    lateinit var current: android.content.Context
}

@Composable
private fun Tool(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick=onClick, color=if(active) Purple.copy(alpha=.2f) else SurfaceDark, shape=RoundedCornerShape(9.dp)) {
        Text(label, Modifier.padding(horizontal=11.dp, vertical=10.dp), color=if(active) Color.White else TextMuted, fontSize=10.sp, fontWeight=FontWeight.SemiBold)
    }
}

@Composable
private fun SmallAction(label: String, modifier: Modifier, onClick: () -> Unit) {
    TextButton(onClick=onClick, modifier=modifier.height(40.dp), contentPadding=PaddingValues(0.dp)) {
        Text(label, color=Color.White, fontSize=10.sp)
    }
}

@Composable
private fun VectorCanvas(doc: VectorDocument, onChange: (VectorDocument) -> Unit, onCommit: (VectorDocument) -> Unit, modifier: Modifier = Modifier) {
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    Canvas(modifier.background(Color(0xFF111722), RoundedCornerShape(15.dp)).pointerInput(doc) {
        detectDragGestures(
            onDragStart = { p ->
                dragStart = p
                val sx = doc.width / size.width
                val sy = doc.height / size.height
                onChange(doc.selectAt(Vec2(p.x * sx, p.y * sy)))
            },
            onDrag = { change, delta ->
                change.consume()
                val sx = doc.width / size.width
                val sy = doc.height / size.height
                onChange(doc.moveSelected(Vec2(delta.x * sx, delta.y * sy)))
            },
            onDragEnd = { onCommit(doc); dragStart = null },
            onDragCancel = { dragStart = null }
        )
    }) {
        val step = 28.dp.toPx()
        var x = 0f
        while (x < size.width) { drawLine(Color(0xFF242C3A), Offset(x,0f), Offset(x,size.height), 1f); x += step }
        var y = 0f
        while (y < size.height) { drawLine(Color(0xFF242C3A), Offset(0f,y), Offset(size.width,y), 1f); y += step }
        doc.objects.forEach { item ->
            val sx = size.width / doc.width
            val sy = size.height / doc.height
            val left = item.bounds.left * sx
            val top = item.bounds.top * sy
            val width = item.bounds.width * sx
            val height = item.bounds.height * sy
            val c = Color(item.color.toInt())
            if (item.kind == ShapeKind.ELLIPSE) {
                drawOval(c, Offset(left,top), androidx.compose.ui.geometry.Size(width,height))
                if (item.id == doc.selectedId) drawOval(Color.White, Offset(left-4,top-4), androidx.compose.ui.geometry.Size(width+8,height+8), style=Stroke(2f))
            } else {
                drawRect(c, Offset(left,top), androidx.compose.ui.geometry.Size(width,height))
                if (item.id == doc.selectedId) drawRect(Color.White, Offset(left-4,top-4), androidx.compose.ui.geometry.Size(width+8,height+8), style=Stroke(2f))
            }
        }
    }
}
