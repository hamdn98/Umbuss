package com.creativenexus.mobile

import android.content.Context
import com.creativenexus.engine.vector.VectorDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ProjectStore {
    fun save(context: Context, document: VectorDocument, name: String = "untitled.cnx") {
        val root = JSONObject()
            .put("format", "creative-nexus")
            .put("version", 1)
            .put("width", document.width)
            .put("height", document.height)
            .put("selectedId", document.selectedId)
        val objects = JSONArray()
        document.objects.forEach { item ->
            objects.put(JSONObject()
                .put("id", item.id)
                .put("kind", item.kind.name)
                .put("left", item.bounds.left)
                .put("top", item.bounds.top)
                .put("right", item.bounds.right)
                .put("bottom", item.bounds.bottom)
                .put("color", item.color))
        }
        root.put("objects", objects)
        File(context.filesDir, name).writeText(root.toString())
    }

    fun load(context: Context, name: String = "untitled.cnx"): String? {
        val file = File(context.filesDir, name)
        return if (file.exists()) file.readText() else null
    }
}
