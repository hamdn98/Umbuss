package com.creativenexus.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.os.Environment
import com.creativenexus.engine.vector.VectorDocument
import com.creativenexus.engine.vector.ShapeKind
import java.io.File
import java.io.FileOutputStream

object PngExporter {
    fun export(context: Context, document: VectorDocument): File {
        val bitmap = Bitmap.createBitmap(document.width, document.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        document.objects.forEach { item ->
            paint.color = item.color.toInt()
            val r = RectF(item.bounds.left, item.bounds.top, item.bounds.right, item.bounds.bottom)
            if (item.kind == ShapeKind.ELLIPSE) canvas.drawOval(r, paint) else canvas.drawRect(r, paint)
        }
        val outDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
        if (!outDir.exists()) outDir.mkdirs()
        val file = File(outDir, "creative-nexus-export.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }
}
