package com.creativenexus.mobile

import org.junit.Assert.assertTrue
import org.junit.Test

class PlaceholderTest {
    @Test fun appPackageHasBasicTestHarness() {
        assertTrue("Creative Nexus test harness is ready", true)
    }
}
