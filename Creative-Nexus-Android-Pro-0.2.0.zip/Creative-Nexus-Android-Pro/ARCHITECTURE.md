# Creative Nexus — Technical Architecture

## Product goal
One mobile creative workspace with shared project/document foundations. Feature modules must share object IDs, selection semantics, transforms, layer ordering, and serialization.

## Runtime layers
1. Presentation: Jetpack Compose, gesture handling, contextual toolbars.
2. Document: scene graph, object IDs, layers, transforms, history.
3. Domain engines: vector geometry, typography, motion, compositing.
4. Platform services: file picker, project storage, bitmap export.
5. Native acceleration (future): Rust/JNI for computational geometry; C++/FFmpeg for audio/video codecs.
6. Rendering: Android Canvas initially; GPU-backed renderer only after device profiling.

## RAM 4 GB constraints
- Never keep decoded source images at original resolution unless actively editing.
- Use preview proxies for large media.
- Use bounded undo history.
- Serialize document state, not rendered frames.
- Export in worker threads and process video frame-by-frame.
- Provide low/medium/high preview quality modes.
- Treat 1080p export as device-dependent; 4K is not a baseline promise.

## Milestones
- 0.2: document model, geometry primitives, history, project JSON, PNG export.
- 0.3: Bezier paths, node editing, SVG import/export.
- 0.4: robust arbitrary-path Boolean engine.
- 0.5: motion timeline and keyframes.
- 0.6: media timeline and FFmpeg pipeline.
