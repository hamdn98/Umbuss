package com.creativenexus.engine.vector

import org.junit.Assert.*
import org.junit.Test

class VectorDocumentTest {
    @Test fun rectangleIntersectionIsCorrect() {
        val parts = RectangleBoolean.apply(RectF(0f,0f,100f,100f), RectF(50f,50f,150f,150f), BooleanOperation.INTERSECT)
        assertEquals(listOf(RectF(50f,50f,100f,100f)), parts)
    }
    @Test fun subtractReturnsRemainingFragments() {
        val parts = RectangleBoolean.apply(RectF(0f,0f,100f,100f), RectF(25f,25f,75f,75f), BooleanOperation.SUBTRACT)
        assertEquals(4, parts.size)
    }
    @Test fun documentMovesSelectedObject() {
        val item = VectorObject(kind=ShapeKind.RECTANGLE, bounds=RectF(0f,0f,20f,20f))
        val moved = VectorDocument().add(item).moveSelected(Vec2(5f,8f))
        assertEquals(5f, moved.objects.single().bounds.left)
        assertEquals(8f, moved.objects.single().bounds.top)
    }
}
