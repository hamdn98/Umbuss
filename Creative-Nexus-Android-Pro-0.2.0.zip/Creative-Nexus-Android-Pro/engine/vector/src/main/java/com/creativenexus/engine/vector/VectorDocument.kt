package com.creativenexus.engine.vector

import kotlin.math.max
import kotlin.math.min
import java.util.UUID

data class Vec2(val x: Float, val y: Float) {
    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
}

data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width get() = max(0f, right - left)
    val height get() = max(0f, bottom - top)
    fun contains(p: Vec2, tolerance: Float = 0f) =
        p.x >= left - tolerance && p.x <= right + tolerance &&
        p.y >= top - tolerance && p.y <= bottom + tolerance
    fun intersects(other: RectF) =
        left < other.right && right > other.left && top < other.bottom && bottom > other.top
    fun intersection(other: RectF): RectF? {
        val l = max(left, other.left); val t = max(top, other.top)
        val r = min(right, other.right); val b = min(bottom, other.bottom)
        return if (r > l && b > t) RectF(l, t, r, b) else null
    }
    fun union(other: RectF) = RectF(min(left, other.left), min(top, other.top), max(right, other.right), max(bottom, other.bottom))
}

enum class ShapeKind { RECTANGLE, ELLIPSE }

data class VectorObject(
    val id: String = UUID.randomUUID().toString(),
    val kind: ShapeKind,
    val bounds: RectF,
    val color: Long = 0xFF8B7CFF
) {
    fun translated(delta: Vec2) = copy(bounds = RectF(
        bounds.left + delta.x, bounds.top + delta.y,
        bounds.right + delta.x, bounds.bottom + delta.y
    ))
    fun hitTest(point: Vec2, tolerance: Float = 10f): Boolean {
        if (!bounds.contains(point, tolerance)) return false
        if (kind == ShapeKind.RECTANGLE) return true
        val rx = max(1f, bounds.width / 2f)
        val ry = max(1f, bounds.height / 2f)
        val cx = (bounds.left + bounds.right) / 2f
        val cy = (bounds.top + bounds.bottom) / 2f
        val nx = (point.x - cx) / rx
        val ny = (point.y - cy) / ry
        return nx * nx + ny * ny <= 1.15f
    }
}

data class VectorDocument(
    val width: Int = 1080,
    val height: Int = 1080,
    val objects: List<VectorObject> = emptyList(),
    val selectedId: String? = null
) {
    fun add(item: VectorObject) = copy(objects = objects + item, selectedId = item.id)
    fun removeSelected() = copy(objects = objects.filterNot { it.id == selectedId }, selectedId = null)
    fun selectAt(point: Vec2): VectorDocument {
        val hit = objects.asReversed().firstOrNull { it.hitTest(point) }
        return copy(selectedId = hit?.id)
    }
    fun moveSelected(delta: Vec2) = copy(objects = objects.map {
        if (it.id == selectedId) it.translated(delta) else it
    })
    fun duplicateSelected(): VectorDocument {
        val source = objects.firstOrNull { it.id == selectedId } ?: return this
        val copyObject = source.copy(id = UUID.randomUUID().toString()).translated(Vec2(24f, 24f))
        return add(copyObject)
    }
}

enum class BooleanOperation { UNION, INTERSECT, SUBTRACT }

/**
 * Axis-aligned rectangle Boolean helper.
 * This deliberately does not pretend to implement arbitrary vector path clipping.
 * SUBTRACT can return up to four non-overlapping rectangular fragments.
 */
object RectangleBoolean {
    fun apply(a: RectF, b: RectF, operation: BooleanOperation): List<RectF> {
        val overlap = a.intersection(b)
        return when (operation) {
            BooleanOperation.UNION -> if (overlap == null) listOf(a, b) else listOf(a.union(b))
            BooleanOperation.INTERSECT -> listOfNotNull(overlap)
            BooleanOperation.SUBTRACT -> {
                if (overlap == null) listOf(a) else buildList {
                    if (overlap.top > a.top) add(RectF(a.left, a.top, a.right, overlap.top))
                    if (overlap.bottom < a.bottom) add(RectF(a.left, overlap.bottom, a.right, a.bottom))
                    if (overlap.left > a.left) add(RectF(a.left, overlap.top, overlap.left, overlap.bottom))
                    if (overlap.right < a.right) add(RectF(overlap.right, overlap.top, a.right, overlap.bottom))
                }
            }
        }
    }
}

class DocumentHistory(private val limit: Int = 60) {
    private val undoStack = ArrayDeque<VectorDocument>()
    private val redoStack = ArrayDeque<VectorDocument>()
    fun commit(before: VectorDocument, after: VectorDocument) {
        undoStack.addLast(before)
        while (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
    }
    fun undo(current: VectorDocument): VectorDocument? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(current)
        return undoStack.removeLast()
    }
    fun redo(current: VectorDocument): VectorDocument? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(current)
        return redoStack.removeLast()
    }
}
