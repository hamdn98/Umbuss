# Creative Nexus Android — Pro Foundation 0.2.0

A native Android creative-workspace foundation designed to be profiled on entry-level devices, including 4 GB RAM / Helio G85 class phones.

## Honest feature status

### Implemented in this source package
- Native Android application with Jetpack Compose.
- Touch-first dark workspace.
- Canvas grid with adaptive drawing.
- Rectangle and ellipse objects.
- Object selection, drag, duplicate, delete.
- Vector document model with stable IDs.
- Vector geometry helpers: bounds, hit testing, translation.
- Boolean operation interface and a conservative rectangle implementation for union/intersection/subtract.
- Undo/redo command history for document mutations.
- JSON project serialization and restoration.
- Export canvas to PNG using Android bitmap APIs.
- GitHub Actions build workflow and unit tests.

### Not implemented yet
- Full arbitrary-path Boolean clipping.
- Pen/Bezier node editor.
- Timeline and keyframe animation.
- Multi-track video editing and FFmpeg integration.
- SVG import/export.
These are planned modules, not advertised as finished features.

## Architecture
- `app`: Android UI, touch interactions, project persistence, PNG export.
- `engine/vector`: platform-independent Kotlin vector document and geometry core.
- Planned native acceleration: Rust via JNI for complex path geometry, C++/FFmpeg for media pipelines, GPU rendering through Android graphics APIs where supported.

## Build with GitHub
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Actions** and select **Build Android APK**.
3. Run the workflow, or push to `main`.
4. Download artifact `creative-nexus-debug-apk` from the completed workflow.
5. Extract the artifact ZIP and install the debug APK.

## Local build
Use Android Studio, JDK 17, Android SDK 35, and Gradle 8.9.
Run `gradle assembleDebug`.

## Device-first performance policy
- Keep vector geometry independent of UI.
- Store project state as lightweight data, not bitmaps.
- Generate previews only when needed.
- Avoid retaining full-resolution frame sequences in memory.
- Keep export work off the UI thread.
- Profile on the actual target phone before raising preview quality.

## Version
0.2.0 — Pro foundation, not a finished professional editor.
