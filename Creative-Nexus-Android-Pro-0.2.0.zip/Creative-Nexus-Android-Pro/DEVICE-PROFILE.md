# Device profile checklist

Target class: Android phone, 4 GB RAM, MediaTek Helio G85 / Mali-G52 class GPU.

Before claiming performance:
- Install a debug or release build on the actual phone.
- Measure cold start, idle memory, canvas frame pacing, and export peak memory.
- Test with 10, 50, 100, and 500 vector objects.
- Test repeated undo/redo and app background/restore.
- Keep a low-memory preview mode available.
- Do not assume every Helio G85 phone has identical thermal or storage behavior.
