//! Undo/redo berbasis tile-diff. Tiap goresan menyimpan snapshot tile 256x256
//! yang tersentuh (kondisi SEBELUM). Undo dan redo adalah operasi yang sama:
//! tukar isi tile layer <-> snapshot, jadi tidak perlu simpan "sesudah" terpisah.
use std::collections::HashSet;
use wgpu::{Device, Extent3d, ImageCopyTexture, Origin3d, Queue, Texture, TextureAspect};

pub const TILE: u32 = 256;
pub const MAX_UNDO: usize = 40;

pub struct TileSnap {
    pub tx: u32,
    pub ty: u32,
    pub tex: Texture,
}

pub struct UndoEntry {
    pub layer: u64, // id layer, bukan indeks
    pub tiles: Vec<TileSnap>,
}

pub struct History {
    pub undo: Vec<UndoEntry>,
    pub redo: Vec<UndoEntry>,
    pub current: Option<UndoEntry>,
    pub touched: HashSet<(u32, u32)>,
    pub scratch: Texture,
}

pub fn tile_texture(device: &Device) -> Texture {
    device.create_texture(&wgpu::TextureDescriptor {
        label: Some("tile"),
        size: Extent3d { width: TILE, height: TILE, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8Unorm,
        usage: wgpu::TextureUsages::COPY_SRC | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    })
}

pub fn copy_at(tex: &Texture, x: u32, y: u32) -> ImageCopyTexture<'_> {
    ImageCopyTexture {
        texture: tex,
        mip_level: 0,
        origin: Origin3d { x, y, z: 0 },
        aspect: TextureAspect::All,
    }
}

pub fn tile_extent() -> Extent3d {
    Extent3d { width: TILE, height: TILE, depth_or_array_layers: 1 }
}

impl History {
    pub fn new(device: &Device) -> Self {
        Self {
            undo: vec![],
            redo: vec![],
            current: None,
            touched: HashSet::new(),
            scratch: tile_texture(device),
        }
    }

    pub fn begin(&mut self, layer: u64) {
        self.current = Some(UndoEntry { layer, tiles: vec![] });
        self.touched.clear();
    }

    pub fn commit(&mut self) {
        if let Some(e) = self.current.take() {
            if !e.tiles.is_empty() {
                self.undo.push(e);
                self.redo.clear();
                if self.undo.len() > MAX_UNDO {
                    self.undo.remove(0);
                }
            }
        }
    }
}

/// Tukar isi tile pada layer dengan snapshot (dipakai untuk undo, redo, dan cancel).
pub fn swap_tiles(device: &Device, queue: &Queue, layer: &Texture, scratch: &Texture, tiles: &[TileSnap]) {
    let mut enc = device.create_command_encoder(&Default::default());
    for t in tiles {
        let (x, y) = (t.tx * TILE, t.ty * TILE);
        enc.copy_texture_to_texture(copy_at(layer, x, y), copy_at(scratch, 0, 0), tile_extent());
        enc.copy_texture_to_texture(copy_at(&t.tex, 0, 0), copy_at(layer, x, y), tile_extent());
        enc.copy_texture_to_texture(copy_at(scratch, 0, 0), copy_at(&t.tex, 0, 0), tile_extent());
    }
    queue.submit([enc.finish()]);
}
