//! Panel UI (egui): toolbar bawah + tab Brush / Layers / File.
//! UI tidak menyentuh engine langsung: ia membaca `Snapshot` dan mengeluarkan `Action`.
//! Input datang dari App (tanpa winit): `touch_down/move/up` dalam piksel layar.
use crate::brush::{BrushSettings, Tool};
use crate::layers::BlendMode;
use glam::Vec2;
use std::time::Instant;

#[derive(Clone, Copy)]
pub struct LayerInfo {
    pub id: u64,
    pub mode: BlendMode,
    pub opacity: f32,
    pub visible: bool,
}

pub struct Snapshot {
    pub layers: Vec<LayerInfo>,
    pub active: usize,
    pub can_undo: bool,
    pub can_redo: bool,
}

#[derive(Clone, Copy, Debug)]
pub enum Action {
    Undo,
    Redo,
    AddLayer,
    SelectLayer(usize),
    SetVisible(usize, bool),
    SetOpacity(usize, f32),
    SetBlend(usize, BlendMode),
    DeleteLayer(usize),
    MoveLayer(usize, bool), // true = naik (ke atas tumpukan)
    // Ditangani App (butuh path file), bukan renderer:
    Save,
    Export,
}

pub struct UiFrame {
    pub jobs: Vec<egui::ClippedPrimitive>,
    pub textures: egui::TexturesDelta,
    pub ppp: f32,
}

#[derive(Clone, Copy, PartialEq)]
enum Tab {
    None,
    Brush,
    Layers,
    File,
}

pub struct Ui {
    ctx: egui::Context,
    tab: Tab,
    rects: Vec<egui::Rect>, // area UI frame terakhir (titik egui)
    popup_open: bool,
    ppp: f32,
    pending: Vec<egui::Event>,
    start: Instant,
    confirm_delete: bool,
}

impl Ui {
    pub fn new(ppp: f32) -> Self {
        let ctx = egui::Context::default();
        ctx.set_pixels_per_point(ppp);
        ctx.set_visuals(egui::Visuals::dark());
        ctx.style_mut(|s| {
            s.spacing.interact_size = egui::vec2(44.0, 38.0);
            s.spacing.item_spacing = egui::vec2(10.0, 10.0);
            s.spacing.slider_width = 170.0;
            s.spacing.icon_width = 26.0;
            for (_, f) in s.text_styles.iter_mut() {
                f.size *= 1.15;
            }
        });
        Self {
            ctx,
            tab: Tab::None,
            rects: vec![],
            popup_open: false,
            ppp,
            pending: vec![],
            start: Instant::now(),
            confirm_delete: false,
        }
    }

    fn pt(&self, p: Vec2) -> egui::Pos2 {
        egui::pos2(p.x / self.ppp, p.y / self.ppp)
    }

    pub fn touch_down(&mut self, p: Vec2) {
        let pos = self.pt(p);
        self.pending.push(egui::Event::PointerMoved(pos));
        self.pending.push(egui::Event::PointerButton {
            pos,
            button: egui::PointerButton::Primary,
            pressed: true,
            modifiers: egui::Modifiers::NONE,
        });
    }

    pub fn touch_move(&mut self, p: Vec2) {
        self.pending.push(egui::Event::PointerMoved(self.pt(p)));
    }

    pub fn touch_up(&mut self, p: Vec2) {
        let pos = self.pt(p);
        self.pending.push(egui::Event::PointerButton {
            pos,
            button: egui::PointerButton::Primary,
            pressed: false,
            modifiers: egui::Modifiers::NONE,
        });
        self.pending.push(egui::Event::PointerGone);
    }

    /// Apakah sentuhan di posisi ini (piksel) milik UI, bukan kanvas?
    pub fn hit(&self, p: Vec2) -> bool {
        if self.popup_open {
            return true; // popup terbuka: semua sentuhan ke egui (tap luar menutupnya)
        }
        let pos = self.pt(p);
        self.rects.iter().any(|r| r.contains(pos))
    }

    /// Jalankan satu frame UI. Mengembalikan (frame untuk dirender, aksi, perlu repaint lagi).
    pub fn run(
        &mut self,
        size: [u32; 2],
        snap: &Snapshot,
        brush: &mut BrushSettings,
        status: &str,
    ) -> (UiFrame, Vec<Action>, bool) {
        let raw = egui::RawInput {
            screen_rect: Some(egui::Rect::from_min_size(
                egui::Pos2::ZERO,
                egui::vec2(size[0] as f32 / self.ppp, size[1] as f32 / self.ppp),
            )),
            time: Some(self.start.elapsed().as_secs_f64()),
            events: std::mem::take(&mut self.pending),
            max_texture_side: Some(2048),
            ..Default::default()
        };
        let mut actions: Vec<Action> = vec![];
        let mut rects: Vec<egui::Rect> = vec![];
        let tab = &mut self.tab;
        let confirm = &mut self.confirm_delete;
        let ctx = self.ctx.clone();

        let out = ctx.run(raw, |ctx| {
            let panel = egui::TopBottomPanel::bottom("bar").show(ctx, |ui| {
                ui.horizontal_wrapped(|ui| {
                    if ui.add_enabled(snap.can_undo, egui::Button::new("Undo")).clicked() {
                        actions.push(Action::Undo);
                    }
                    if ui.add_enabled(snap.can_redo, egui::Button::new("Redo")).clicked() {
                        actions.push(Action::Redo);
                    }
                    if ui.button("+ Layer").clicked() {
                        actions.push(Action::AddLayer);
                    }
                    ui.separator();
                    for (t, name) in [(Tab::Brush, "Brush"), (Tab::Layers, "Layers"), (Tab::File, "File")] {
                        if ui.selectable_label(*tab == t, name).clicked() {
                            *tab = if *tab == t { Tab::None } else { t };
                        }
                    }
                });

                match *tab {
                    Tab::Brush => {
                        ui.horizontal(|ui| {
                            for (t, name) in [(Tool::Brush, "Brush"), (Tool::Eraser, "Eraser"), (Tool::Smudge, "Smudge")] {
                                ui.selectable_value(&mut brush.tool, t, name);
                            }
                        });
                        egui::Grid::new("brush").num_columns(2).show(ui, |ui| {
                            ui.label("Size");
                            ui.add(egui::Slider::new(&mut brush.size, 1.0..=300.0).logarithmic(true));
                            ui.end_row();
                            ui.label(if brush.tool == Tool::Smudge { "Strength" } else { "Opacity" });
                            ui.add(egui::Slider::new(&mut brush.opacity, 0.0..=1.0));
                            ui.end_row();
                            ui.label("Hardness");
                            ui.add(egui::Slider::new(&mut brush.hardness, 0.0..=1.0));
                            ui.end_row();
                            ui.label("Spacing");
                            ui.add(egui::Slider::new(&mut brush.spacing, 0.02..=0.5));
                            ui.end_row();
                            ui.label("Color");
                            ui.color_edit_button_rgb(&mut brush.color);
                            ui.end_row();
                        });
                        ui.checkbox(&mut brush.finger_draws, "Jari ikut menggambar (matikan = stylus saja)");
                    }
                    Tab::Layers => {
                        egui::ScrollArea::vertical().max_height(180.0).show(ui, |ui| {
                            for i in (0..snap.layers.len()).rev() {
                                ui.horizontal(|ui| {
                                    let mut vis = snap.layers[i].visible;
                                    if ui.checkbox(&mut vis, "").changed() {
                                        actions.push(Action::SetVisible(i, vis));
                                    }
                                    let name = format!("Layer {}", snap.layers[i].id + 1);
                                    if ui.selectable_label(i == snap.active, name).clicked() {
                                        actions.push(Action::SelectLayer(i));
                                        *confirm = false;
                                    }
                                });
                            }
                        });
                        let a = snap.active;
                        if let Some(l) = snap.layers.get(a) {
                            let mut op = l.opacity;
                            if ui.add(egui::Slider::new(&mut op, 0.0..=1.0).text("Opacity")).changed() {
                                actions.push(Action::SetOpacity(a, op));
                            }
                            egui::ComboBox::from_label("Blend").selected_text(l.mode.name()).show_ui(ui, |ui| {
                                for m in BlendMode::ALL {
                                    if ui.selectable_label(l.mode == m, m.name()).clicked() {
                                        actions.push(Action::SetBlend(a, m));
                                    }
                                }
                            });
                            ui.horizontal(|ui| {
                                if ui.add_enabled(a + 1 < snap.layers.len(), egui::Button::new("Naik")).clicked() {
                                    actions.push(Action::MoveLayer(a, true));
                                }
                                if ui.add_enabled(a > 0, egui::Button::new("Turun")).clicked() {
                                    actions.push(Action::MoveLayer(a, false));
                                }
                                if *confirm {
                                    if ui.button("Yakin hapus?").clicked() {
                                        actions.push(Action::DeleteLayer(a));
                                        *confirm = false;
                                    }
                                    if ui.button("Batal").clicked() {
                                        *confirm = false;
                                    }
                                } else if ui.add_enabled(snap.layers.len() > 1, egui::Button::new("Hapus")).clicked() {
                                    *confirm = true;
                                }
                            });
                        }
                    }
                    Tab::File => {
                        ui.horizontal(|ui| {
                            if ui.button("Save").clicked() {
                                actions.push(Action::Save);
                            }
                            if ui.button("Export PNG").clicked() {
                                actions.push(Action::Export);
                            }
                        });
                        if !status.is_empty() {
                            ui.label(status);
                        }
                    }
                    Tab::None => {}
                }
                ui.add_space(18.0); // jarak dari gesture bar sistem
            });
            rects.push(panel.response.rect);
        });

        self.rects = rects;
        self.popup_open = ctx.memory(|m| m.any_popup_open());
        self.ppp = out.pixels_per_point;

        let repaint = out.viewport_output.values().any(|v| v.repaint_delay.is_zero());
        let jobs = ctx.tessellate(out.shapes, out.pixels_per_point);
        let frame = UiFrame { jobs, textures: out.textures_delta, ppp: out.pixels_per_point };
        (frame, actions, repaint)
    }
}
