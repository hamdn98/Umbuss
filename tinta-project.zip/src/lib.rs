mod brush;
mod history;
mod layers;
mod platform;
mod project;
mod renderer;
mod ui;

use android_activity::{
    input::{InputEvent, MotionAction, MotionEvent, Pointer, ToolType},
    AndroidApp, InputStatus, MainEvent, PollEvent,
};
use brush::{BrushSettings, Dab, InputPoint, StrokeBuilder, Tool};
use glam::Vec2;
use platform::NativeTarget;
use renderer::{Renderer, View};
use std::{
    collections::{HashMap, HashSet},
    path::PathBuf,
    time::{Duration, Instant},
};
use ui::{Action, Ui};

/// Jari kedua yang muncul dalam rentang ini membatalkan goresan jari (salah sentuh).
const CANCEL_WINDOW: Duration = Duration::from_millis(250);
/// Tap multi-jari harus lebih singkat dari ini.
const TAP_MAX: Duration = Duration::from_millis(350);
const TAP_SLOP: f32 = 20.0;
/// Jari yang mendarat saat/segera setelah stylus dianggap telapak tangan.
const PEN_GRACE: Duration = Duration::from_millis(300);

#[derive(Clone, Copy, PartialEq, Debug)]
enum Phase {
    Started,
    Moved,
    Ended,
    Cancelled,
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Kind {
    Finger,
    Pen,
    Eraser, // ujung penghapus stylus
}

#[derive(Clone, Copy)]
struct Ptr {
    id: u64,
    pos: Vec2,
    pressure: f32,
    kind: Kind,
    major: f32, // ukuran kontak (px), untuk deteksi telapak
}

fn ptr_of(p: &Pointer<'_>) -> Ptr {
    Ptr {
        id: p.pointer_id() as u32 as u64,
        pos: Vec2::new(p.x(), p.y()),
        pressure: p.pressure().clamp(0.0, 1.0),
        kind: match p.tool_type() {
            ToolType::Stylus => Kind::Pen,
            ToolType::Eraser => Kind::Eraser,
            _ => Kind::Finger,
        },
        major: p.touch_major(),
    }
}

/// Pelacak tap multi-jari: 2 jari = undo, 3 jari = redo, 4 jari = layer baru.
struct Tap {
    start: Instant,
    max_touches: usize,
    moved: bool,
    origins: HashMap<u64, Vec2>,
}

struct App {
    app: AndroidApp,
    ppp: f32,
    palm_px: f32,
    has_window: bool,
    need_redraw: bool,

    renderer: Option<Renderer>,
    ui: Option<Ui>,
    view: View,

    brush: BrushSettings,
    stroke_brush: BrushSettings, // salinan brush saat goresan dimulai (+ override eraser stylus)
    stroke: StrokeBuilder,
    dabs: Vec<Dab>,

    touches: HashMap<u64, Vec2>, // hanya jari
    drawing: Option<u64>,
    stroke_start: Instant,
    gesture: Option<(Vec2, f32)>,
    tap: Option<Tap>,

    pen_id: Option<u64>,
    pen_up: Option<Instant>,
    ignored: HashSet<u64>, // jari yang ditolak (telapak / dekat stylus)
    ui_touches: HashSet<u64>,

    dir: PathBuf,
    export_dir: PathBuf,
    status: String,
}

impl App {
    fn new(app: AndroidApp, dir: PathBuf, export_dir: PathBuf, ppp: f32) -> Self {
        Self {
            app,
            ppp,
            palm_px: 128.0 * ppp, // ~0,8 inci
            has_window: false,
            need_redraw: false,
            renderer: None,
            ui: None,
            view: View { zoom: 1.0, pan: Vec2::ZERO },
            brush: BrushSettings::default(),
            stroke_brush: BrushSettings::default(),
            stroke: StrokeBuilder::default(),
            dabs: Vec::new(),
            touches: HashMap::new(),
            drawing: None,
            stroke_start: Instant::now(),
            gesture: None,
            tap: None,
            pen_id: None,
            pen_up: None,
            ignored: HashSet::new(),
            ui_touches: HashSet::new(),
            dir,
            export_dir,
            status: String::new(),
        }
    }

    // ---------- lifecycle ----------

    fn window_init(&mut self) {
        let Some(nw) = self.app.native_window() else { return };
        let (w, h) = (nw.width().max(1) as u32, nw.height().max(1) as u32);
        let target = NativeTarget(nw);
        match self.renderer.as_mut() {
            // Resume berikutnya: kanvas, layer, dan undo tetap ada.
            Some(r) => r.attach(target, w, h),
            None => {
                let r = pollster::block_on(Renderer::new(target, w, h));
                self.view = View::fit(r.size());
                self.renderer = Some(r);
                self.load_project();
            }
        }
        if self.ui.is_none() {
            self.ui = Some(Ui::new(self.ppp));
        }
        self.has_window = true;
        self.need_redraw = true;
    }

    fn window_term(&mut self) {
        self.cancel_stroke();
        self.save_project(); // autosave sebelum app masuk background
        self.touches.clear();
        self.ignored.clear();
        self.ui_touches.clear();
        self.gesture = None;
        self.tap = None;
        self.pen_id = None;
        if let Some(r) = self.renderer.as_mut() {
            r.detach();
        }
        self.has_window = false;
    }

    fn resized(&mut self) {
        if let (Some(r), Some(nw)) = (self.renderer.as_mut(), self.app.native_window()) {
            r.resize(nw.width().max(1) as u32, nw.height().max(1) as u32);
            self.need_redraw = true;
        }
    }

    // ---------- input mentah ----------

    fn on_input(&mut self, ev: &InputEvent) -> InputStatus {
        match ev {
            InputEvent::MotionEvent(m) => {
                self.on_motion(m);
                InputStatus::Handled
            }
            _ => InputStatus::Unhandled,
        }
    }

    fn on_motion(&mut self, m: &MotionEvent) {
        match m.action() {
            MotionAction::Down | MotionAction::PointerDown => {
                let p = ptr_of(&m.pointer_at_index(m.pointer_index()));
                self.pointer(Phase::Started, p);
            }
            MotionAction::Up | MotionAction::PointerUp => {
                let p = ptr_of(&m.pointer_at_index(m.pointer_index()));
                self.pointer(Phase::Ended, p);
            }
            MotionAction::Move => {
                let ps: Vec<Ptr> = m.pointers().map(|p| ptr_of(&p)).collect();
                for p in ps {
                    self.pointer(Phase::Moved, p);
                }
            }
            MotionAction::Cancel => {
                let ps: Vec<Ptr> = m.pointers().map(|p| ptr_of(&p)).collect();
                for p in ps {
                    self.pointer(Phase::Cancelled, p);
                }
            }
            _ => {}
        }
    }

    /// Arahkan satu pointer: ke UI kalau dimulai di atas panel, selain itu ke kanvas.
    fn pointer(&mut self, phase: Phase, p: Ptr) {
        let to_ui = match phase {
            Phase::Started => {
                let hit = self.ui.as_ref().map_or(false, |u| u.hit(p.pos));
                if hit {
                    self.ui_touches.insert(p.id);
                }
                hit
            }
            Phase::Moved => self.ui_touches.contains(&p.id),
            _ => self.ui_touches.remove(&p.id),
        };
        if to_ui {
            if let Some(ui) = self.ui.as_mut() {
                match phase {
                    Phase::Started => ui.touch_down(p.pos),
                    Phase::Moved => ui.touch_move(p.pos),
                    _ => ui.touch_up(p.pos),
                }
            }
            self.need_redraw = true;
            return;
        }
        match p.kind {
            Kind::Finger => self.finger(phase, p),
            _ => self.pen(phase, p),
        }
        self.flush();
    }

    // ---------- stylus ----------

    fn pen(&mut self, phase: Phase, p: Ptr) {
        match phase {
            Phase::Started => {
                // Stylus menang atas jari: batalkan goresan jari dan buang semua jari
                // yang sedang menyentuh (hampir pasti telapak tangan).
                if self.drawing.is_some() {
                    self.cancel_stroke();
                }
                let ids: Vec<u64> = self.touches.keys().copied().collect();
                self.ignored.extend(ids);
                self.touches.clear();
                self.gesture = None;
                self.tap = None;
                self.pen_id = Some(p.id);
                let cp = self.view.to_canvas(p.pos);
                self.begin_stroke(p.id, cp, p.pressure, p.kind);
            }
            Phase::Moved => {
                if self.drawing == Some(p.id) {
                    let ip = InputPoint { pos: self.view.to_canvas(p.pos), pressure: p.pressure };
                    self.stroke.push(ip, &self.stroke_brush, &mut self.dabs);
                }
            }
            Phase::Ended | Phase::Cancelled => {
                if self.drawing == Some(p.id) {
                    if phase == Phase::Cancelled {
                        self.cancel_stroke();
                    } else {
                        self.end_stroke();
                    }
                }
                if self.pen_id == Some(p.id) {
                    self.pen_id = None;
                    self.pen_up = Some(Instant::now());
                }
            }
        }
    }

    // ---------- jari ----------

    fn finger(&mut self, phase: Phase, p: Ptr) {
        if self.ignored.contains(&p.id) {
            if matches!(phase, Phase::Ended | Phase::Cancelled) {
                self.ignored.remove(&p.id);
            }
            return;
        }
        if phase == Phase::Started {
            let palm = p.major > self.palm_px;
            let pen_near = self.pen_id.is_some() || self.pen_up.map_or(false, |t| t.elapsed() < PEN_GRACE);
            if palm || pen_near {
                self.ignored.insert(p.id);
                return;
            }
        }
        self.touch(phase, p);
    }

    fn touch(&mut self, phase: Phase, p: Ptr) {
        match phase {
            Phase::Started => {
                self.touches.insert(p.id, p.pos);
                self.gesture = None;
                if self.touches.len() == 1 {
                    self.tap = None;
                    if self.brush.finger_draws {
                        let cp = self.view.to_canvas(p.pos);
                        self.begin_stroke(p.id, cp, 1.0, Kind::Finger);
                    }
                } else {
                    if self.drawing.is_some() {
                        if self.stroke_start.elapsed() < CANCEL_WINDOW {
                            self.cancel_stroke();
                        } else {
                            self.end_stroke();
                        }
                    }
                    let origins = self.touches.clone();
                    let tap = self.tap.get_or_insert_with(|| Tap {
                        start: Instant::now(),
                        max_touches: 0,
                        moved: false,
                        origins,
                    });
                    tap.origins.insert(p.id, p.pos);
                    tap.max_touches = tap.max_touches.max(self.touches.len());
                }
            }
            Phase::Moved => {
                self.touches.insert(p.id, p.pos);
                if self.drawing == Some(p.id) {
                    let ip = InputPoint { pos: self.view.to_canvas(p.pos), pressure: 1.0 };
                    self.stroke.push(ip, &self.stroke_brush, &mut self.dabs);
                } else {
                    if let Some(tap) = self.tap.as_mut() {
                        if let Some(o) = tap.origins.get(&p.id) {
                            if o.distance(p.pos) > TAP_SLOP {
                                tap.moved = true;
                            }
                        }
                    }
                    if self.touches.len() == 2 {
                        self.pan_zoom();
                    }
                }
            }
            Phase::Ended | Phase::Cancelled => {
                if self.drawing == Some(p.id) {
                    self.end_stroke();
                }
                if phase == Phase::Cancelled {
                    if let Some(tap) = self.tap.as_mut() {
                        tap.moved = true;
                    }
                }
                self.touches.remove(&p.id);
                self.gesture = None;
                if self.touches.is_empty() {
                    if let Some(tap) = self.tap.take() {
                        if !tap.moved && tap.start.elapsed() < TAP_MAX {
                            if let Some(r) = self.renderer.as_mut() {
                                match tap.max_touches {
                                    2 => r.undo(),
                                    3 => r.redo(),
                                    4 => r.add_layer(),
                                    _ => {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    fn pan_zoom(&mut self) {
        let mut it = self.touches.values();
        let (a, b) = (*it.next().unwrap(), *it.next().unwrap());
        let mid = (a + b) * 0.5;
        let dist = a.distance(b).max(1.0);
        if let Some((pm, pd)) = self.gesture {
            let anchor = self.view.to_canvas(pm);
            let z = (self.view.zoom * dist / pd).clamp(0.05, 40.0);
            self.view.zoom = z;
            self.view.pan = mid - anchor * z;
        }
        self.gesture = Some((mid, dist));
    }

    // ---------- goresan ----------

    fn begin_stroke(&mut self, id: u64, pos: Vec2, pressure: f32, kind: Kind) {
        self.drawing = Some(id);
        self.stroke_start = Instant::now();
        self.stroke_brush = self.brush.clone();
        if kind == Kind::Eraser {
            self.stroke_brush.tool = Tool::Eraser; // ujung penghapus stylus
        }
        if let Some(r) = self.renderer.as_mut() {
            r.begin_stroke();
        }
        self.stroke.begin(InputPoint { pos, pressure }, &self.stroke_brush, &mut self.dabs);
    }

    fn end_stroke(&mut self) {
        if self.drawing.take().is_some() {
            self.stroke.end(&self.stroke_brush, &mut self.dabs);
            self.flush();
            if let Some(r) = self.renderer.as_mut() {
                r.commit_stroke();
            }
        }
    }

    fn cancel_stroke(&mut self) {
        if self.drawing.take().is_some() {
            self.dabs.clear();
            self.stroke = StrokeBuilder::default();
            if let Some(r) = self.renderer.as_mut() {
                r.cancel_stroke();
            }
        }
    }

    fn flush(&mut self) {
        if let Some(r) = self.renderer.as_mut() {
            if !self.dabs.is_empty() {
                r.draw_dabs(&self.dabs, self.stroke_brush.tool);
                self.dabs.clear();
            }
        }
        self.need_redraw = true;
    }

    // ---------- frame ----------

    fn redraw(&mut self) {
        self.need_redraw = false;
        let (mut want_save, mut want_export) = (false, false);
        {
            let (Some(r), Some(ui)) = (self.renderer.as_mut(), self.ui.as_mut()) else { return };
            let snap = r.snapshot();
            let (frame, actions, repaint) = ui.run(r.size_px(), &snap, &mut self.brush, &self.status);
            // Jangan ubah layer/history di tengah goresan.
            if self.drawing.is_none() {
                for a in actions {
                    match a {
                        Action::Save => want_save = true,
                        Action::Export => want_export = true,
                        other => r.apply(other),
                    }
                }
            }
            r.render(&self.view, Some(frame));
            if repaint {
                self.need_redraw = true;
            }
        }
        if want_save {
            self.save_project();
        }
        if want_export {
            self.export_png();
        }
        if want_save || want_export {
            self.need_redraw = true;
        }
    }

    // ---------- file ----------

    fn project_path(&self) -> PathBuf {
        self.dir.join("project.tinta")
    }

    fn save_project(&mut self) {
        let path = self.project_path();
        let Some(r) = self.renderer.as_mut() else { return };
        let (layers, active) = r.export_layers();
        self.status = match project::save(&path, &layers, active) {
            Ok(()) => "Project saved".into(),
            Err(e) => format!("Save failed: {e}"),
        };
    }

    fn load_project(&mut self) {
        let path = self.project_path();
        if !path.exists() {
            return;
        }
        let Some(r) = self.renderer.as_mut() else { return };
        self.status = match project::load(&path) {
            Ok((layers, active)) => {
                r.import_layers(layers, active);
                "Project loaded".into()
            }
            Err(e) => format!("Load failed: {e}"),
        };
    }

    fn export_png(&mut self) {
        let secs = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_secs());
        let path = self.export_dir.join(format!("tinta-{secs}.png"));
        let Some(r) = self.renderer.as_mut() else { return };
        let rgba = r.export_flat();
        self.status = match project::export_png(&path, rgba) {
            Ok(()) => format!("Exported: {}", path.display()),
            Err(e) => format!("Export failed: {e}"),
        };
    }
}

#[no_mangle]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_max_level(log::LevelFilter::Info));
    let dir = app.internal_data_path().unwrap_or_else(|| PathBuf::from("."));
    let export_dir = app.external_data_path().unwrap_or_else(|| dir.clone());
    let ppp = app.config().density().map_or(2.5, |d| d as f32 / 160.0).clamp(1.0, 4.5);
    let mut state = App::new(app.clone(), dir, export_dir, ppp);
    let mut quit = false;

    while !quit {
        // Tidur sampai ada event, kecuali masih ada frame yang harus digambar.
        let timeout = if state.need_redraw && state.has_window { Some(Duration::ZERO) } else { None };
        app.poll_events(timeout, |event| {
            if let PollEvent::Main(ev) = event {
                match ev {
                    MainEvent::InitWindow { .. } => state.window_init(),
                    MainEvent::TerminateWindow { .. } => state.window_term(),
                    MainEvent::WindowResized { .. } | MainEvent::ContentRectChanged { .. } => state.resized(),
                    MainEvent::RedrawNeeded { .. } => state.need_redraw = true,
                    MainEvent::Destroy => quit = true,
                    _ => {}
                }
            }
        });
        app.input_events(|ev| state.on_input(ev));
        if state.need_redraw && state.has_window {
            state.redraw();
        }
    }
}
