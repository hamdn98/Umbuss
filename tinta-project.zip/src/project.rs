//! Format proyek `.tinta`: zip (tanpa kompresi) berisi manifest.json + satu PNG per layer.
//! Di memori/GPU piksel premultiplied; di PNG disimpan straight alpha (kompatibel dengan app lain).
use crate::layers::BlendMode;
use crate::renderer::{CANVAS_H, CANVAS_W};
use serde::{Deserialize, Serialize};
use std::{
    fs::{self, File},
    io::{Cursor, Read, Write},
    path::Path,
};

type R<T> = Result<T, Box<dyn std::error::Error>>;

pub struct LayerData {
    pub rgba: Vec<u8>, // premultiplied, CANVAS_W * CANVAS_H * 4
    pub mode: BlendMode,
    pub opacity: f32,
    pub visible: bool,
}

#[derive(Serialize, Deserialize)]
struct LayerMeta {
    file: String,
    mode: u32,
    opacity: f32,
    visible: bool,
}

#[derive(Serialize, Deserialize)]
struct Manifest {
    version: u32,
    width: u32,
    height: u32,
    active: usize,
    layers: Vec<LayerMeta>,
}

fn unpremultiply(buf: &mut [u8]) {
    for px in buf.chunks_exact_mut(4) {
        let a = px[3] as u32;
        if a > 0 && a < 255 {
            for c in &mut px[..3] {
                *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
            }
        }
    }
}

fn premultiply(buf: &mut [u8]) {
    for px in buf.chunks_exact_mut(4) {
        let a = px[3] as u32;
        if a < 255 {
            for c in &mut px[..3] {
                *c = ((*c as u32 * a + 127) / 255) as u8;
            }
        }
    }
}

fn encode_png(rgba: &[u8]) -> R<Vec<u8>> {
    let mut out = Vec::new();
    {
        let mut enc = png::Encoder::new(&mut out, CANVAS_W, CANVAS_H);
        enc.set_color(png::ColorType::Rgba);
        enc.set_depth(png::BitDepth::Eight);
        let mut w = enc.write_header()?;
        w.write_image_data(rgba)?;
    }
    Ok(out)
}

fn decode_png(bytes: &[u8]) -> R<Vec<u8>> {
    let mut reader = png::Decoder::new(Cursor::new(bytes)).read_info()?;
    let mut buf = vec![0; reader.output_buffer_size()];
    let info = reader.next_frame(&mut buf)?;
    if info.width != CANVAS_W
        || info.height != CANVAS_H
        || info.color_type != png::ColorType::Rgba
        || info.bit_depth != png::BitDepth::Eight
    {
        return Err("layer PNG: ukuran/format tidak sesuai (harus RGBA 8-bit, ukuran kanvas)".into());
    }
    buf.truncate(info.buffer_size());
    Ok(buf)
}

pub fn save(path: &Path, layers: &[LayerData], active: usize) -> R<()> {
    if let Some(dir) = path.parent() {
        fs::create_dir_all(dir)?;
    }
    // Tulis ke file sementara lalu rename: autosave yang terputus tidak merusak proyek lama.
    let tmp = path.with_extension("tmp");
    {
        let mut zip = zip::ZipWriter::new(File::create(&tmp)?);
        let opts = zip::write::FileOptions::default().compression_method(zip::CompressionMethod::Stored);
        let mut metas = Vec::new();
        for (i, l) in layers.iter().enumerate() {
            let mut px = l.rgba.clone();
            unpremultiply(&mut px);
            let file = format!("layer_{i}.png");
            zip.start_file(file.clone(), opts)?;
            zip.write_all(&encode_png(&px)?)?;
            metas.push(LayerMeta { file, mode: l.mode as u32, opacity: l.opacity, visible: l.visible });
        }
        let manifest = Manifest { version: 1, width: CANVAS_W, height: CANVAS_H, active, layers: metas };
        zip.start_file("manifest.json", opts)?;
        zip.write_all(&serde_json::to_vec_pretty(&manifest)?)?;
        zip.finish()?;
    }
    fs::rename(&tmp, path)?;
    Ok(())
}

pub fn load(path: &Path) -> R<(Vec<LayerData>, usize)> {
    let mut zip = zip::ZipArchive::new(File::open(path)?)?;
    let mut raw = Vec::new();
    zip.by_name("manifest.json")?.read_to_end(&mut raw)?;
    let m: Manifest = serde_json::from_slice(&raw)?;
    if m.width != CANVAS_W || m.height != CANVAS_H {
        return Err(format!("ukuran kanvas proyek {}x{} tidak didukung", m.width, m.height).into());
    }
    let mut layers = Vec::new();
    for meta in &m.layers {
        let mut bytes = Vec::new();
        zip.by_name(&meta.file)?.read_to_end(&mut bytes)?;
        let mut px = decode_png(&bytes)?;
        premultiply(&mut px);
        layers.push(LayerData {
            rgba: px,
            mode: BlendMode::from_u32(meta.mode),
            opacity: meta.opacity,
            visible: meta.visible,
        });
    }
    Ok((layers, m.active))
}

/// Export hasil gabungan semua layer sebagai PNG (latar transparan).
pub fn export_png(path: &Path, mut rgba_premul: Vec<u8>) -> R<()> {
    if let Some(dir) = path.parent() {
        fs::create_dir_all(dir)?;
    }
    unpremultiply(&mut rgba_premul);
    fs::write(path, encode_png(&rgba_premul)?)?;
    Ok(())
}
