use crate::brush::{Dab, Tool};
use crate::platform::NativeTarget;
use crate::history::{copy_at, swap_tiles, tile_extent, tile_texture, History, TileSnap, TILE};
use crate::layers::{Compositor, Layer};
use crate::project::LayerData;
use crate::ui::{Action, LayerInfo, Snapshot, UiFrame};
use glam::Vec2;

pub const CANVAS_W: u32 = 2048;
pub const CANVAS_H: u32 = 2048;
const MAX_DABS: usize = 32768;
const MAX_LAYERS: usize = 8;
const TILES: u32 = CANVAS_W / TILE; // kanvas harus kelipatan TILE

#[derive(Clone, Copy)]
pub struct View {
    pub zoom: f32,
    pub pan: Vec2,
}

impl View {
    pub fn fit(screen: Vec2) -> Self {
        let c = Vec2::new(CANVAS_W as f32, CANVAS_H as f32);
        let zoom = (screen.x / c.x).min(screen.y / c.y) * 0.95;
        Self { zoom, pan: (screen - c * zoom) * 0.5 }
    }
    pub fn to_canvas(&self, p: Vec2) -> Vec2 {
        (p - self.pan) / self.zoom
    }
}

fn make_config(surface: &wgpu::Surface, adapter: &wgpu::Adapter, w: u32, h: u32) -> wgpu::SurfaceConfiguration {
    let caps = surface.get_capabilities(adapter);
    let mut c = surface.get_default_config(adapter, w.max(1), h.max(1)).expect("surface config");
    // Non-sRGB: kanvas disimpan dalam ruang warna tampilan.
    c.format = caps.formats.iter().copied().find(|f| !f.is_srgb()).unwrap_or(caps.formats[0]);
    c.present_mode = wgpu::PresentMode::Fifo;
    c
}

pub struct Renderer {
    instance: wgpu::Instance,
    adapter: wgpu::Adapter,
    device: wgpu::Device,
    queue: wgpu::Queue,
    // Surface boleh hilang (Suspended) tanpa kehilangan kanvas.
    surface: Option<wgpu::Surface<'static>>,
    config: wgpu::SurfaceConfiguration,

    layers: Vec<Layer>,
    active: usize,
    comp: Compositor,
    dirty: bool,
    history: History,

    dab_pipeline: wgpu::RenderPipeline,
    dab_bind: wgpu::BindGroup,
    dab_buf: wgpu::Buffer,
    erase_pipeline: wgpu::RenderPipeline,
    smudge_pipeline: wgpu::RenderPipeline,
    smudge_bind: wgpu::BindGroup,
    smudge_src: wgpu::Texture, // salinan region layer untuk dibaca smudge
    next_id: u64,
    display_pipeline: wgpu::RenderPipeline,
    display_binds: [wgpu::BindGroup; 2],
    display_ubo: wgpu::Buffer,

    egui_r: egui_wgpu::Renderer,
}

impl Renderer {
    pub async fn new(target: NativeTarget, width: u32, height: u32) -> Self {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::VULKAN,
            ..Default::default()
        });
        let surface = instance.create_surface(target).expect("create_surface");
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .expect("adapter");
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: None,
                    required_features: wgpu::Features::empty(),
                    required_limits: adapter.limits(),
                },
                None,
            )
            .await
            .expect("device");
        let config = make_config(&surface, &adapter, width, height);
        surface.configure(&device, &config);

        // --- Layer & compositor & history ---
        let layers = vec![Layer::new(&device, 0)];
        let comp = Compositor::new(&device);
        let history = History::new(&device);

        // --- Pipeline dab ---
        let dab_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("dab"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/dab.wgsl").into()),
        });
        let dab_ubo = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("dab_ubo"),
            size: 16,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        queue.write_buffer(&dab_ubo, 0, bytemuck::bytes_of(&[CANVAS_W as f32, CANVAS_H as f32, 0.0, 0.0]));
        let dab_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: None,
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let dab_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &dab_bgl,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: dab_ubo.as_entire_binding() }],
        });
        let dab_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[&dab_bgl],
            push_constant_ranges: &[],
        });
        let over = wgpu::BlendComponent {
            src_factor: wgpu::BlendFactor::One,
            dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
            operation: wgpu::BlendOperation::Add,
        };
        let dab_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("dab"),
            layout: Some(&dab_layout),
            vertex: wgpu::VertexState {
                module: &dab_shader,
                entry_point: "vs",
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Dab>() as u64,
                    step_mode: wgpu::VertexStepMode::Instance,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32, 2 => Float32, 3 => Float32x4],
                }],
            },
            fragment: Some(wgpu::FragmentState {
                module: &dab_shader,
                entry_point: "fs",
                targets: &[Some(wgpu::ColorTargetState {
                    format: wgpu::TextureFormat::Rgba8Unorm,
                    blend: Some(wgpu::BlendState { color: over, alpha: over }),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleStrip, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
        });
        // Eraser: dst *= (1 - a)
        let erase_c = wgpu::BlendComponent {
            src_factor: wgpu::BlendFactor::Zero,
            dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
            operation: wgpu::BlendOperation::Add,
        };
        let erase_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("erase"),
            layout: Some(&dab_layout),
            vertex: wgpu::VertexState {
                module: &dab_shader,
                entry_point: "vs",
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Dab>() as u64,
                    step_mode: wgpu::VertexStepMode::Instance,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32, 2 => Float32, 3 => Float32x4],
                }],
            },
            fragment: Some(wgpu::FragmentState {
                module: &dab_shader,
                entry_point: "fs",
                targets: &[Some(wgpu::ColorTargetState {
                    format: wgpu::TextureFormat::Rgba8Unorm,
                    blend: Some(wgpu::BlendState { color: erase_c, alpha: erase_c }),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleStrip, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
        });

        // Smudge: baca salinan region layer, tulis dengan REPLACE.
        let smudge_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("smudge"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/smudge.wgsl").into()),
        });
        let smudge_src = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("smudge_src"),
            size: wgpu::Extent3d { width: CANVAS_W, height: CANVAS_H, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        let smudge_view = smudge_src.create_view(&Default::default());
        let smudge_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let smudge_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: None,
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let smudge_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &smudge_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: dab_ubo.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&smudge_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&smudge_sampler) },
            ],
        });
        let smudge_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[&smudge_bgl],
            push_constant_ranges: &[],
        });
        let smudge_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("smudge"),
            layout: Some(&smudge_layout),
            vertex: wgpu::VertexState {
                module: &smudge_shader,
                entry_point: "vs",
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Dab>() as u64,
                    step_mode: wgpu::VertexStepMode::Instance,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32, 2 => Float32, 3 => Float32x4],
                }],
            },
            fragment: Some(wgpu::FragmentState {
                module: &smudge_shader,
                entry_point: "fs",
                targets: &[Some(wgpu::TextureFormat::Rgba8Unorm.into())],
            }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleStrip, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
        });

        let dab_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("dabs"),
            size: (MAX_DABS * std::mem::size_of::<Dab>()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // --- Pipeline tampilan ---
        let disp_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("display"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/display.wgsl").into()),
        });
        let display_ubo = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("display_ubo"),
            size: 32,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let disp_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: None,
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let mk_bind = |view: &wgpu::TextureView| {
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &disp_bgl,
                entries: &[
                    wgpu::BindGroupEntry { binding: 0, resource: display_ubo.as_entire_binding() },
                    wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(view) },
                    wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&sampler) },
                ],
            })
        };
        let display_binds = [mk_bind(&comp.views[0]), mk_bind(&comp.views[1])];
        let disp_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[&disp_bgl],
            push_constant_ranges: &[],
        });
        let display_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("display"),
            layout: Some(&disp_layout),
            vertex: wgpu::VertexState { module: &disp_shader, entry_point: "vs", buffers: &[] },
            fragment: Some(wgpu::FragmentState {
                module: &disp_shader,
                entry_point: "fs",
                targets: &[Some(config.format.into())],
            }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleStrip, ..Default::default() },
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
        });

        let egui_r = egui_wgpu::Renderer::new(&device, config.format, None, 1);

        Self {
            instance, adapter, device, queue,
            surface: Some(surface), config,
            next_id: 1, layers, active: 0, comp, dirty: true, history,
            dab_pipeline, dab_bind, dab_buf,
            erase_pipeline, smudge_pipeline, smudge_bind, smudge_src,
            display_pipeline, display_binds, display_ubo,
            egui_r,
        }
    }

    // ---------- surface lifecycle ----------

    /// Pasang surface baru setelah Resumed; kanvas & layer tetap utuh.
    pub fn attach(&mut self, target: NativeTarget, width: u32, height: u32) {
        let surface = self.instance.create_surface(target).expect("create_surface");
        self.config = make_config(&surface, &self.adapter, width, height);
        surface.configure(&self.device, &self.config);
        self.surface = Some(surface);
    }

    pub fn detach(&mut self) {
        self.surface = None;
    }

    pub fn size_px(&self) -> [u32; 2] {
        [self.config.width, self.config.height]
    }

    pub fn size(&self) -> Vec2 {
        Vec2::new(self.config.width as f32, self.config.height as f32)
    }

    pub fn resize(&mut self, w: u32, h: u32) {
        if w == 0 || h == 0 {
            return;
        }
        self.config.width = w;
        self.config.height = h;
        if let Some(s) = &self.surface {
            s.configure(&self.device, &self.config);
        }
    }

    // ---------- layer ----------

    pub fn add_layer(&mut self) {
        if self.layers.len() < MAX_LAYERS {
            let id = self.next_id;
            self.next_id += 1;
            self.layers.push(Layer::new(&self.device, id));
            self.active = self.layers.len() - 1;
            self.dirty = true;
        }
    }

    // ---------- stroke & history ----------

    pub fn begin_stroke(&mut self) {
        self.history.begin(self.layers[self.active].id);
    }

    pub fn commit_stroke(&mut self) {
        self.history.commit();
    }

    /// Batalkan goresan yang sedang berjalan (mis. jari kedua muncul).
    pub fn cancel_stroke(&mut self) {
        if let Some(e) = self.history.current.take() {
            if !e.tiles.is_empty() {
                swap_tiles(&self.device, &self.queue, &self.layers[self.layer_index(e.layer).unwrap_or(0)].tex, &self.history.scratch, &e.tiles);
                self.dirty = true;
            }
        }
    }

    pub fn undo(&mut self) {
        if let Some(e) = self.history.undo.pop() {
            swap_tiles(&self.device, &self.queue, &self.layers[e.layer].tex, &self.history.scratch, &e.tiles);
            self.history.redo.push(e);
            self.dirty = true;
        }
    }

    pub fn redo(&mut self) {
        if let Some(e) = self.history.redo.pop() {
            swap_tiles(&self.device, &self.queue, &self.layers[e.layer].tex, &self.history.scratch, &e.tiles);
            self.history.undo.push(e);
            self.dirty = true;
        }
    }

    /// Gambar dab ke layer aktif. Tile yang pertama kali tersentuh di goresan
    /// ini di-snapshot dulu (sebelum dab menimpanya).
    pub fn draw_dabs(&mut self, dabs: &[Dab], tool: Tool) {
        if dabs.is_empty() {
            return;
        }
        let layer = &self.layers[self.active];

        if let Some(cur) = self.history.current.as_mut() {
            let mut enc = self.device.create_command_encoder(&Default::default());
            let mut any = false;
            let max_t = (TILES - 1) as f32;
            for d in dabs {
                let r = d.radius + 1.0;
                let t = TILE as f32;
                let tx0 = ((d.pos[0] - r) / t).floor().clamp(0.0, max_t) as u32;
                let tx1 = ((d.pos[0] + r) / t).floor().clamp(0.0, max_t) as u32;
                let ty0 = ((d.pos[1] - r) / t).floor().clamp(0.0, max_t) as u32;
                let ty1 = ((d.pos[1] + r) / t).floor().clamp(0.0, max_t) as u32;
                for ty in ty0..=ty1 {
                    for tx in tx0..=tx1 {
                        if self.history.touched.insert((tx, ty)) {
                            let snap = tile_texture(&self.device);
                            enc.copy_texture_to_texture(
                                copy_at(&layer.tex, tx * TILE, ty * TILE),
                                copy_at(&snap, 0, 0),
                                tile_extent(),
                            );
                            cur.tiles.push(TileSnap { tx, ty, tex: snap });
                            any = true;
                        }
                    }
                }
            }
            if any {
                self.queue.submit([enc.finish()]);
            }
        }

        if tool == Tool::Smudge {
            self.smudge_dabs(dabs);
            self.dirty = true;
            return;
        }
        let pipeline = if tool == Tool::Eraser { &self.erase_pipeline } else { &self.dab_pipeline };

        for chunk in dabs.chunks(MAX_DABS) {
            self.queue.write_buffer(&self.dab_buf, 0, bytemuck::cast_slice(chunk));
            let mut enc = self.device.create_command_encoder(&Default::default());
            {
                let mut pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("dabs"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &layer.view,
                        resolve_target: None,
                        ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(pipeline);
                pass.set_bind_group(0, &self.dab_bind, &[]);
                pass.set_vertex_buffer(0, self.dab_buf.slice(..));
                pass.draw(0..4, 0..chunk.len() as u32);
            }
            self.queue.submit([enc.finish()]);
        }
        self.dirty = true;
    }

    fn layer_index(&self, id: u64) -> Option<usize> {
        self.layers.iter().position(|l| l.id == id)
    }

    /// Smudge harus berurutan: tiap dab membaca hasil dab sebelumnya. Sebelum tiap dab,
    /// region di sekitarnya disalin ke `smudge_src` (kecil), lalu dab digambar satu per satu.
    fn smudge_dabs(&self, dabs: &[Dab]) {
        let layer = &self.layers[self.active];
        let (wf, hf) = (CANVAS_W as f32, CANVAS_H as f32);
        for chunk in dabs.chunks(MAX_DABS) {
            self.queue.write_buffer(&self.dab_buf, 0, bytemuck::cast_slice(chunk));
            let mut enc = self.device.create_command_encoder(&Default::default());
            for (i, d) in chunk.iter().enumerate() {
                let m = d.radius + 3.0 + d.color[0].abs() + d.color[1].abs();
                let x0 = (d.pos[0] - m).floor().clamp(0.0, wf) as u32;
                let x1 = (d.pos[0] + m).ceil().clamp(0.0, wf) as u32;
                let y0 = (d.pos[1] - m).floor().clamp(0.0, hf) as u32;
                let y1 = (d.pos[1] + m).ceil().clamp(0.0, hf) as u32;
                if x1 <= x0 || y1 <= y0 {
                    continue;
                }
                enc.copy_texture_to_texture(
                    copy_at(&layer.tex, x0, y0),
                    copy_at(&self.smudge_src, x0, y0),
                    wgpu::Extent3d { width: x1 - x0, height: y1 - y0, depth_or_array_layers: 1 },
                );
                let mut pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("smudge"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &layer.view,
                        resolve_target: None,
                        ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.smudge_pipeline);
                pass.set_bind_group(0, &self.smudge_bind, &[]);
                pass.set_vertex_buffer(0, self.dab_buf.slice(..));
                pass.draw(0..4, i as u32..i as u32 + 1);
            }
            self.queue.submit([enc.finish()]);
        }
    }

    // ---------- baca/tulis piksel (simpan, export, buka) ----------

    fn read_texture(&self, tex: &wgpu::Texture) -> Vec<u8> {
        let bpr = CANVAS_W * 4; // 8192: kelipatan 256, sesuai syarat wgpu
        let buf = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("readback"),
            size: (bpr * CANVAS_H) as u64,
            usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_buffer(
            wgpu::ImageCopyTexture {
                texture: tex,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::ImageCopyBuffer {
                buffer: &buf,
                layout: wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(bpr), rows_per_image: Some(CANVAS_H) },
            },
            wgpu::Extent3d { width: CANVAS_W, height: CANVAS_H, depth_or_array_layers: 1 },
        );
        self.queue.submit([enc.finish()]);
        let slice = buf.slice(..);
        let (tx, rx) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |r| {
            let _ = tx.send(r);
        });
        self.device.poll(wgpu::Maintain::Wait);
        rx.recv().expect("map channel").expect("map_async");
        let data = slice.get_mapped_range().to_vec();
        buf.unmap();
        data
    }

    fn write_texture(&self, tex: &wgpu::Texture, rgba: &[u8]) {
        self.queue.write_texture(
            wgpu::ImageCopyTexture {
                texture: tex,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            rgba,
            wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(CANVAS_W * 4), rows_per_image: Some(CANVAS_H) },
            wgpu::Extent3d { width: CANVAS_W, height: CANVAS_H, depth_or_array_layers: 1 },
        );
    }

    pub fn export_layers(&self) -> (Vec<LayerData>, usize) {
        let data = self
            .layers
            .iter()
            .map(|l| LayerData { rgba: self.read_texture(&l.tex), mode: l.mode, opacity: l.opacity, visible: l.visible })
            .collect();
        (data, self.active)
    }

    /// Gambar gabungan semua layer (premultiplied RGBA).
    pub fn export_flat(&mut self) -> Vec<u8> {
        if self.dirty {
            self.comp.composite(&self.device, &self.queue, &self.layers);
            self.dirty = false;
        }
        self.read_texture(&self.comp.texs[self.comp.result])
    }

    /// Ganti seluruh isi kanvas dengan proyek yang dimuat; undo di-reset.
    pub fn import_layers(&mut self, data: Vec<LayerData>, active: usize) {
        let mut layers = Vec::new();
        for d in data.into_iter().take(MAX_LAYERS) {
            let id = self.next_id;
            self.next_id += 1;
            let mut l = Layer::new(&self.device, id);
            l.mode = d.mode;
            l.opacity = d.opacity;
            l.visible = d.visible;
            self.write_texture(&l.tex, &d.rgba);
            layers.push(l);
        }
        if layers.is_empty() {
            let id = self.next_id;
            self.next_id += 1;
            layers.push(Layer::new(&self.device, id));
        }
        self.active = active.min(layers.len() - 1);
        self.layers = layers;
        self.history = History::new(&self.device);
        self.dirty = true;
    }

    // ---------- state untuk UI ----------

    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            layers: self
                .layers
                .iter()
                .map(|l| LayerInfo { id: l.id, mode: l.mode, opacity: l.opacity, visible: l.visible })
                .collect(),
            active: self.active,
            can_undo: !self.history.undo.is_empty(),
            can_redo: !self.history.redo.is_empty(),
        }
    }

    pub fn apply(&mut self, a: Action) {
        let n = self.layers.len();
        match a {
            Action::Undo => self.undo(),
            Action::Redo => self.redo(),
            Action::AddLayer => self.add_layer(),
            Action::SelectLayer(i) if i < n => self.active = i,
            Action::SetVisible(i, v) if i < n => {
                self.layers[i].visible = v;
                self.dirty = true;
            }
            Action::SetOpacity(i, o) if i < n => {
                self.layers[i].opacity = o.clamp(0.0, 1.0);
                self.dirty = true;
            }
            Action::SetBlend(i, m) if i < n => {
                self.layers[i].mode = m;
                self.dirty = true;
            }
            Action::DeleteLayer(i) if i < n && n > 1 => {
                let id = self.layers.remove(i).id;
                // Riwayat goresan layer ini tidak bisa dipakai lagi.
                self.history.undo.retain(|e| e.layer != id);
                self.history.redo.retain(|e| e.layer != id);
                self.active = if self.active > i { self.active - 1 } else { self.active.min(self.layers.len() - 1) };
                self.dirty = true;
            }
            Action::MoveLayer(i, up) if i < n => {
                let j = if up { i + 1 } else { i.wrapping_sub(1) };
                if j < n {
                    self.layers.swap(i, j);
                    self.active = if self.active == i { j } else if self.active == j { i } else { self.active };
                    self.dirty = true;
                }
            }
            _ => {}
        }
    }

    // ---------- render ----------

    pub fn render(&mut self, view: &View, ui: Option<UiFrame>) {
        // Upload tekstur egui (atlas font) selalu, walau surface sedang tidak ada.
        if let Some(f) = &ui {
            for (id, delta) in &f.textures.set {
                self.egui_r.update_texture(&self.device, &self.queue, *id, delta);
            }
        }
        if self.dirty {
            self.comp.composite(&self.device, &self.queue, &self.layers);
            self.dirty = false;
        }
        let Some(surface) = &self.surface else { return };
        let frame = match surface.get_current_texture() {
            Ok(f) => f,
            Err(_) => {
                surface.configure(&self.device, &self.config);
                return;
            }
        };
        let target = frame.texture.create_view(&Default::default());
        let u: [f32; 8] = [
            CANVAS_W as f32, CANVAS_H as f32, view.zoom, 0.0,
            view.pan.x, view.pan.y, self.config.width as f32, self.config.height as f32,
        ];
        self.queue.write_buffer(&self.display_ubo, 0, bytemuck::bytes_of(&u));

        let sd = egui_wgpu::ScreenDescriptor {
            size_in_pixels: [self.config.width, self.config.height],
            pixels_per_point: ui.as_ref().map_or(1.0, |f| f.ppp),
        };
        let mut enc = self.device.create_command_encoder(&Default::default());
        let extra = match &ui {
            Some(f) => self.egui_r.update_buffers(&self.device, &self.queue, &mut enc, &f.jobs, &sd),
            None => vec![],
        };
        {
            let mut pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("display"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &target,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color { r: 0.18, g: 0.18, b: 0.2, a: 1.0 }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.display_pipeline);
            pass.set_bind_group(0, &self.display_binds[self.comp.result], &[]);
            pass.draw(0..4, 0..1);
            if let Some(f) = &ui {
                self.egui_r.render(&mut pass, &f.jobs, &sd);
            }
        }
        self.queue.submit(extra.into_iter().chain(std::iter::once(enc.finish())));
        frame.present();

        if let Some(f) = &ui {
            for id in &f.textures.free {
                self.egui_r.free_texture(id);
            }
        }
    }
}
