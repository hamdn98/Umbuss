// Smudge: tiap dab mengambil warna dari posisi dab sebelumnya (offset di color.xy)
// lalu mencampurnya ke posisi sekarang. Sumber = salinan region layer sebelum dab ini.
struct U { canvas: vec2<f32>, pad: vec2<f32> };
@group(0) @binding(0) var<uniform> u: U;
@group(0) @binding(1) var src: texture_2d<f32>;
@group(0) @binding(2) var samp: sampler;

struct In {
    @builtin(vertex_index) vi: u32,
    @location(0) pos: vec2<f32>,
    @location(1) radius: f32,
    @location(2) hardness: f32,
    @location(3) color: vec4<f32>,
};
struct Out {
    @builtin(position) p: vec4<f32>,
    @location(0) local: vec2<f32>,
    @location(1) hardness: f32,
    @location(2) color: vec4<f32>,
};

@vertex
fn vs(i: In) -> Out {
    var c = array<vec2<f32>, 4>(vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(-1.0, 1.0), vec2(1.0, 1.0));
    let l = c[i.vi];
    let r = i.radius + 1.0;
    let px = i.pos + l * r;
    var o: Out;
    o.p = vec4(px.x / u.canvas.x * 2.0 - 1.0, 1.0 - px.y / u.canvas.y * 2.0, 0.0, 1.0);
    o.local = l * r / max(i.radius, 0.001);
    o.hardness = min(i.hardness, 0.99);
    o.color = i.color;
    return o;
}

@fragment
fn fs(i: Out) -> @location(0) vec4<f32> {
    let dims = vec2<f32>(textureDimensions(src));
    let here = textureLoad(src, vec2<i32>(i.p.xy), 0);
    let there = textureSampleLevel(src, samp, (i.p.xy + i.color.xy) / dims, 0.0);
    let w = i.color.a * (1.0 - smoothstep(i.hardness, 1.0, length(i.local)));
    return mix(here, there, w); // premultiplied, tanpa blending (REPLACE)
}
