struct U { canvas: vec2<f32>, pad: vec2<f32> };
@group(0) @binding(0) var<uniform> u: U;

struct In {
    @builtin(vertex_index) vi: u32,
    @location(0) pos: vec2<f32>,
    @location(1) radius: f32,
    @location(2) hardness: f32,
    @location(3) color: vec4<f32>,
};
struct Out {
    @builtin(position) p: vec4<f32>,
    @location(0) local: vec2<f32>,
    @location(1) hardness: f32,
    @location(2) color: vec4<f32>,
};

@vertex
fn vs(i: In) -> Out {
    var c = array<vec2<f32>, 4>(vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(-1.0, 1.0), vec2(1.0, 1.0));
    let l = c[i.vi];
    let r = i.radius + 1.0; // +1px untuk antialias
    let px = i.pos + l * r;
    var o: Out;
    o.p = vec4(px.x / u.canvas.x * 2.0 - 1.0, 1.0 - px.y / u.canvas.y * 2.0, 0.0, 1.0);
    o.local = l * r / max(i.radius, 0.001);
    o.hardness = min(i.hardness, 0.99);
    o.color = i.color;
    return o;
}

@fragment
fn fs(i: Out) -> @location(0) vec4<f32> {
    let a = i.color.a * (1.0 - smoothstep(i.hardness, 1.0, length(i.local)));
    return vec4(i.color.rgb * a, a); // premultiplied
}
