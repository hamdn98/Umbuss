struct L { mode: u32, opacity: f32, p0: f32, p1: f32 };
@group(0) @binding(0) var<uniform> l: L;
@group(0) @binding(1) var back: texture_2d<f32>;
@group(0) @binding(2) var src: texture_2d<f32>;

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4<f32> {
    var p = array<vec2<f32>, 3>(vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
    return vec4(p[vi], 0.0, 1.0);
}

fn blend(mode: u32, cb: vec3<f32>, cs: vec3<f32>) -> vec3<f32> {
    var r = cs; // 0 = normal
    if (mode == 1u) {
        r = cb * cs;                       // multiply
    } else if (mode == 2u) {
        r = cb + cs - cb * cs;             // screen
    } else if (mode == 3u) {               // overlay
        let lo = 2.0 * cb * cs;
        let hi = vec3(1.0) - 2.0 * (vec3(1.0) - cb) * (vec3(1.0) - cs);
        r = select(hi, lo, cb <= vec3(0.5));
    } else if (mode == 4u) {
        r = min(cb + cs, vec3(1.0));       // add
    }
    return r;
}

@fragment
fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
    let xy = vec2<i32>(pos.xy);
    let b = textureLoad(back, xy, 0);
    let s = textureLoad(src, xy, 0) * l.opacity; // premultiplied
    let cb = select(vec3(0.0), b.rgb / max(b.a, 0.0001), b.a > 0.0);
    let cs = select(vec3(0.0), s.rgb / max(s.a, 0.0001), s.a > 0.0);
    let bl = blend(l.mode, cb, cs);
    let rgb = s.rgb * (1.0 - b.a) + b.rgb * (1.0 - s.a) + s.a * b.a * bl;
    let a = s.a + b.a * (1.0 - s.a);
    return vec4(rgb, a);
}
