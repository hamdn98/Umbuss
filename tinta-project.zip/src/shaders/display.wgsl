struct V { canvas: vec2<f32>, zoom: f32, pad: f32, pan: vec2<f32>, screen: vec2<f32> };
@group(0) @binding(0) var<uniform> v: V;
@group(0) @binding(1) var tex: texture_2d<f32>;
@group(0) @binding(2) var samp: sampler;

struct Out { @builtin(position) p: vec4<f32>, @location(0) uv: vec2<f32> };

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> Out {
    var c = array<vec2<f32>, 4>(vec2(0.0, 0.0), vec2(1.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0));
    let uv = c[vi];
    let sp = uv * v.canvas * v.zoom + v.pan;
    var o: Out;
    o.p = vec4(sp.x / v.screen.x * 2.0 - 1.0, 1.0 - sp.y / v.screen.y * 2.0, 0.0, 1.0);
    o.uv = uv;
    return o;
}

@fragment
fn fs(i: Out) -> @location(0) vec4<f32> {
    let c = textureSample(tex, samp, i.uv); // premultiplied
    return vec4(c.rgb + (1.0 - c.a), 1.0);  // di atas kertas putih
}
