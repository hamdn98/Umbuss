use crate::renderer::{CANVAS_H, CANVAS_W};
use wgpu::{Device, Queue};

#[derive(Clone, Copy, PartialEq, Debug)]
#[repr(u32)]
pub enum BlendMode {
    Normal = 0,
    Multiply = 1,
    Screen = 2,
    Overlay = 3,
    Add = 4,
}

#[allow(dead_code)] // dipakai oleh UI di langkah berikutnya
impl BlendMode {
    pub const ALL: [BlendMode; 5] = [Self::Normal, Self::Multiply, Self::Screen, Self::Overlay, Self::Add];

    pub fn from_u32(v: u32) -> Self {
        match v {
            1 => Self::Multiply,
            2 => Self::Screen,
            3 => Self::Overlay,
            4 => Self::Add,
            _ => Self::Normal,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Self::Normal => "Normal",
            Self::Multiply => "Multiply",
            Self::Screen => "Screen",
            Self::Overlay => "Overlay",
            Self::Add => "Add",
        }
    }

    pub fn next(self) -> Self {
        match self {
            Self::Normal => Self::Multiply,
            Self::Multiply => Self::Screen,
            Self::Screen => Self::Overlay,
            Self::Overlay => Self::Add,
            Self::Add => Self::Normal,
        }
    }
}

#[allow(dead_code)]
pub struct Layer {
    pub id: u64, // stabil walau layer diurut ulang/dihapus (dipakai history)
    pub tex: wgpu::Texture,
    pub view: wgpu::TextureView,
    pub ubo: wgpu::Buffer,
    pub mode: BlendMode,
    pub opacity: f32,
    pub visible: bool,
}

impl Layer {
    pub fn new(device: &Device, id: u64) -> Self {
        let tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("layer"),
            size: wgpu::Extent3d { width: CANVAS_W, height: CANVAS_H, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT
                | wgpu::TextureUsages::TEXTURE_BINDING
                | wgpu::TextureUsages::COPY_SRC
                | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        let view = tex.create_view(&Default::default());
        let ubo = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("layer_ubo"),
            size: 16,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        Self { id, tex, view, ubo, mode: BlendMode::Normal, opacity: 1.0, visible: true }
    }

    fn sync(&self, queue: &Queue) {
        queue.write_buffer(
            &self.ubo,
            0,
            bytemuck::bytes_of(&[self.mode as u32, self.opacity.to_bits(), 0u32, 0u32]),
        );
    }
}

/// Menggabungkan semua layer (bawah -> atas) dengan ping-pong dua tekstur,
/// karena blend mode perlu membaca backdrop.
pub struct Compositor {
    pipeline: wgpu::RenderPipeline,
    bgl: wgpu::BindGroupLayout,
    pub views: [wgpu::TextureView; 2],
    pub texs: [wgpu::Texture; 2],
    pub result: usize,
}

impl Compositor {
    pub fn new(device: &Device) -> Self {
        let mk = || {
            let tex = device
                .create_texture(&wgpu::TextureDescriptor {
                    label: Some("composite"),
                    size: wgpu::Extent3d { width: CANVAS_W, height: CANVAS_H, depth_or_array_layers: 1 },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format: wgpu::TextureFormat::Rgba8Unorm,
                    usage: wgpu::TextureUsages::RENDER_ATTACHMENT
                        | wgpu::TextureUsages::TEXTURE_BINDING
                        | wgpu::TextureUsages::COPY_SRC,
                    view_formats: &[],
                })
            ;
            let view = tex.create_view(&Default::default());
            (tex, view)
        };
        let ((t0, v0), (t1, v1)) = (mk(), mk());
        let views = [v0, v1];
        let texs = [t0, t1];
        let tex_entry = |binding| wgpu::BindGroupLayoutEntry {
            binding,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Texture {
                sample_type: wgpu::TextureSampleType::Float { filterable: false },
                view_dimension: wgpu::TextureViewDimension::D2,
                multisampled: false,
            },
            count: None,
        };
        let bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: None,
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                tex_entry(1),
                tex_entry(2),
            ],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("composite"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/composite.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[&bgl],
            push_constant_ranges: &[],
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("composite"),
            layout: Some(&layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs", buffers: &[] },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: "fs",
                targets: &[Some(wgpu::TextureFormat::Rgba8Unorm.into())],
            }),
            primitive: Default::default(),
            depth_stencil: None,
            multisample: Default::default(),
            multiview: None,
        });
        Self { pipeline, bgl, views, texs, result: 0 }
    }

    pub fn composite(&mut self, device: &Device, queue: &Queue, layers: &[Layer]) {
        let mut enc = device.create_command_encoder(&Default::default());
        let mut src = 0usize;
        // Mulai dari transparan.
        enc.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &self.views[0],
                resolve_target: None,
                ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store },
            })],
            depth_stencil_attachment: None,
            timestamp_writes: None,
            occlusion_query_set: None,
        });
        for layer in layers.iter().filter(|l| l.visible) {
            layer.sync(queue);
            let dst = 1 - src;
            let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &self.bgl,
                entries: &[
                    wgpu::BindGroupEntry { binding: 0, resource: layer.ubo.as_entire_binding() },
                    wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&self.views[src]) },
                    wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(&layer.view) },
                ],
            });
            {
                let mut pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: None,
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &self.views[dst],
                        resolve_target: None,
                        ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store },
                    })],
                    depth_stencil_attachment: None,
                    timestamp_writes: None,
                    occlusion_query_set: None,
                });
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &bind, &[]);
                pass.draw(0..3, 0..1);
            }
            src = dst;
        }
        self.result = src;
        queue.submit([enc.finish()]);
    }
}
