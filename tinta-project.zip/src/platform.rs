//! Jembatan ANativeWindow -> wgpu (tanpa winit).
use ndk::native_window::NativeWindow;
use raw_window_handle::{
    AndroidNdkWindowHandle, DisplayHandle, HandleError, HasDisplayHandle, HasWindowHandle, RawWindowHandle,
    WindowHandle,
};

pub struct NativeTarget(pub NativeWindow);

impl HasWindowHandle for NativeTarget {
    fn window_handle(&self) -> Result<WindowHandle<'_>, HandleError> {
        let ptr = self.0.ptr().cast::<std::ffi::c_void>();
        let raw = RawWindowHandle::AndroidNdk(AndroidNdkWindowHandle::new(ptr));
        // Aman: NativeWindow dimiliki struct ini selama handle dipinjam.
        Ok(unsafe { WindowHandle::borrow_raw(raw) })
    }
}

impl HasDisplayHandle for NativeTarget {
    fn display_handle(&self) -> Result<DisplayHandle<'_>, HandleError> {
        Ok(DisplayHandle::android())
    }
}
