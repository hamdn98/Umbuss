use bytemuck::{Pod, Zeroable};
use glam::Vec2;

#[derive(Clone, Copy)]
pub struct InputPoint {
    pub pos: Vec2, // koordinat kanvas
    pub pressure: f32, // 0..1
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Tool {
    Brush,
    Eraser,
    Smudge,
}

#[derive(Clone)]
pub struct BrushSettings {
    pub size: f32,     // diameter px
    pub spacing: f32,  // fraksi dari diameter
    pub hardness: f32, // 0..1
    pub opacity: f32,  // 0..1
    pub color: [f32; 3],
    pub tool: Tool,
    pub finger_draws: bool, // false = jari hanya untuk gesture (mode stylus saja)
}

impl Default for BrushSettings {
    fn default() -> Self {
        Self { size: 24.0, spacing: 0.08, hardness: 0.7, opacity: 0.9, color: [0.05, 0.05, 0.08], tool: Tool::Brush, finger_draws: true }
    }
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
pub struct Dab {
    pub pos: [f32; 2],
    pub radius: f32,
    pub hardness: f32,
    pub color: [f32; 4],
}

impl Dab {
    /// `off` hanya dipakai smudge: vektor ke posisi dab sebelumnya (disimpan di color.xy).
    fn new(p: InputPoint, b: &BrushSettings, off: Vec2) -> Self {
        // Kurva tekanan sederhana; ganti dengan kurva yang bisa diedit nanti.
        let radius = b.size * 0.5 * (0.2 + 0.8 * p.pressure);
        let alpha = b.opacity * (0.4 + 0.6 * p.pressure);
        let color = match b.tool {
            Tool::Smudge => [off.x, off.y, 0.0, alpha * 0.6],
            _ => [b.color[0], b.color[1], b.color[2], alpha],
        };
        Dab { pos: p.pos.to_array(), radius, hardness: b.hardness, color }
    }
}

fn catmull_rom(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, t: f32) -> Vec2 {
    let t2 = t * t;
    let t3 = t2 * t;
    0.5 * ((2.0 * p1)
        + (p2 - p0) * t
        + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
        + (3.0 * p1 - p0 - 3.0 * p2 + p3) * t3)
}

#[derive(Default)]
pub struct StrokeBuilder {
    pts: Vec<InputPoint>,
    carry: f32,
    last: Option<Vec2>,
    last_dab: Option<Vec2>, // posisi dab sebelumnya (untuk smudge)
}

impl StrokeBuilder {
    pub fn begin(&mut self, p: InputPoint, b: &BrushSettings, out: &mut Vec<Dab>) {
        self.pts.clear();
        self.pts.push(p);
        self.pts.push(p);
        self.carry = 0.0;
        self.last = Some(p.pos);
        self.last_dab = None;
        let d = self.make_dab(p, b);
        out.push(d);
    }

    pub fn push(&mut self, p: InputPoint, b: &BrushSettings, out: &mut Vec<Dab>) {
        self.pts.push(p);
        let n = self.pts.len();
        if n >= 4 {
            self.segment(n - 4, b, out);
        }
        if self.pts.len() > 16 {
            let k = self.pts.len() - 3;
            self.pts.drain(..k);
        }
    }

    pub fn end(&mut self, b: &BrushSettings, out: &mut Vec<Dab>) {
        if let Some(&l) = self.pts.last() {
            self.pts.push(l);
            let n = self.pts.len();
            if n >= 4 {
                self.segment(n - 4, b, out);
            }
        }
        self.pts.clear();
        self.last = None;
        self.last_dab = None;
    }

    fn make_dab(&mut self, p: InputPoint, b: &BrushSettings) -> Dab {
        let off = self.last_dab.map_or(Vec2::ZERO, |l| l - p.pos);
        self.last_dab = Some(p.pos);
        Dab::new(p, b, off)
    }

    /// Sampel spline antara pts[i+1] dan pts[i+2], keluarkan dab tiap `spacing`.
    fn segment(&mut self, i: usize, b: &BrushSettings, out: &mut Vec<Dab>) {
        let (a, p1, p2, d) = (self.pts[i], self.pts[i + 1], self.pts[i + 2], self.pts[i + 3]);
        let min_sp = if b.tool == Tool::Smudge { 0.1 } else { 0.0 };
        let spacing = (b.size * b.spacing.max(min_sp)).max(0.5);
        let steps = ((p1.pos.distance(p2.pos) / (spacing * 0.5)).ceil() as usize).clamp(1, 512);
        let mut prev = self.last.unwrap_or(p1.pos);
        for s in 1..=steps {
            let t = s as f32 / steps as f32;
            let pos = catmull_rom(a.pos, p1.pos, p2.pos, d.pos, t);
            let pressure = p1.pressure + (p2.pressure - p1.pressure) * t;
            self.carry += pos.distance(prev);
            prev = pos;
            while self.carry >= spacing {
                self.carry -= spacing;
                let d = self.make_dab(InputPoint { pos, pressure }, b);
                out.push(d);
            }
        }
        self.last = Some(prev);
    }
}
