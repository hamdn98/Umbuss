# Tinta — Procreate-style painter, pure Rust (Android)

## Build lewat GitHub Actions (tanpa setup lokal)
1. Buat repo di GitHub, upload isi folder `tinta/` (termasuk `.github/workflows/android.yml`).
2. Tab **Actions** > "Android APK" > tunggu selesai (pertama kali ~10-15 menit).
3. Buka run yang selesai > **Artifacts** > unduh `tinta-apk`, install `tinta.apk` (izinkan sumber tidak dikenal).
4. Kalau gagal: buka log step "Build APK", salin error compiler.
   Jalankan manual kapan saja lewat tombol "Run workflow".

## Build lokal
rustup target add aarch64-linux-android
cargo install cargo-apk
export ANDROID_HOME=... ANDROID_NDK_ROOT=...
cargo apk run --release

## Fitur (langkah 1–4)
- wgpu/Vulkan, kanvas 2048x2048 RGBA8 premultiplied, tetap utuh saat app di-suspend
- Brush stamp + Catmull-Rom + tekanan (size & opacity)
- Layer (maks 8) + blend mode Normal/Multiply/Screen/Overlay/Add, dikomposit di GPU
  (hasil di-cache, hanya dihitung ulang saat ada perubahan)
- Undo/redo tile-diff (tile 256x256, 40 langkah). Undo & redo = operasi tukar tile yang sama.

## UI (egui)
- Toolbar bawah: Undo, Redo, + Layer, tab Brush dan Layers
- Brush: size (log), opacity, hardness, spacing, color picker
- Layers: pilih, tampil/sembunyi, opacity, blend mode
- Sentuhan yang mulai di atas panel masuk ke UI, sisanya ke kanvas

## File
- Autosave ke `project.tinta` (zip: manifest.json + PNG per layer) saat app masuk background,
  dimuat otomatis saat dibuka lagi. Tab File: Save manual dan Export PNG (gabungan, transparan).
- Export masuk ke `Android/data/<package>/files/` (terlihat lewat file manager/adb).
- Simpan/export memblokir UI sebentar (readback GPU sinkron).

## Tool
- Brush, Eraser (blend dst*(1-a)), Smudge (tiap dab menyalin region kecil lalu mencampur dari dab sebelumnya)
- Ujung penghapus stylus otomatis jadi Eraser

## Layer
- Naik/Turun, Hapus (dengan konfirmasi). History memakai id layer stabil;
  menghapus layer membuang riwayatnya (hapus layer sendiri belum bisa di-undo).

## Input (android-activity langsung, tanpa winit)
- Tipe alat asli dari MotionEvent: jari / stylus / penghapus stylus
- Palm rejection: jari yang mendarat saat atau <300 ms setelah stylus, atau dengan kontak
  > ~0,8 inci, diabaikan. Stylus mendarat -> goresan jari dibatalkan & jari aktif dibuang.
- Brush > "Jari ikut menggambar": matikan untuk mode stylus saja (jari tetap untuk pan/zoom/tap)

## Gesture
- 1 jari/stylus: gambar
- 2 jari geser/pinch: pan + zoom
- Tap 2 jari: undo | tap 3 jari: redo | tap 4 jari: layer baru
- Jari kedua muncul <250 ms setelah goresan mulai: goresan dibatalkan (salah sentuh)

## TODO
- Undo untuk hapus/urut layer
- Kurva tekanan yang bisa diedit, eraser, smudge
- Sampel `history` MotionEvent (stylus 240 Hz) agar goresan lebih halus
- Share/export ke galeri (butuh JNI/MediaStore), autosave berkala + simpan di thread terpisah
- Storage kanvas tiled sparse (saat ini satu tekstur penuh per layer)
